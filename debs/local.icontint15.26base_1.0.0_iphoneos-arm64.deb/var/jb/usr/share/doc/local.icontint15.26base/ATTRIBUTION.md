# IconTint15 — adaptation of 26Home

Original author: ngkhoi / ngkoi.
Source: https://github.com/ngkoi/26Home
Upstream commit: 3b9378591c1c7d69d79080d130fa0d3dd2b358a1.
Code license: CC BY-NC-SA 4.0; noncommercial adaptation under the same terms.

Changes: iOS 15 target, iOS 18 menu routing, removal of active glass/blur/specular effects, separate preferences and notifications, Russian mode labels, and Home18 artwork import.
The original Homescreen18 executable and its installation scripts are not used.
Third-party application and Settings artwork supplied by the user is not relicensed by the code license.
